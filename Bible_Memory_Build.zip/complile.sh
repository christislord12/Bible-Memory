javac BibleMemory.java
